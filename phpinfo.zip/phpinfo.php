<?php
	
	phpinfo();
	
?>