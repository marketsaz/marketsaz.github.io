<?php
// HTTP
define('HTTP_SERVER', '');
define('HTTP_CATALOG', '');
define('HTTP_IMAGE', '');

// HTTPS
define('HTTPS_SERVER', '');
define('HTTPS_IMAGE', '');

// DIR
define('DIR_APPLICATION', '');
define('DIR_SYSTEM', '');
define('DIR_DATABASE', '');
define('DIR_LANGUAGE', '');
define('DIR_TEMPLATE', '');
define('DIR_CONFIG', '');
define('DIR_IMAGE', '');
define('DIR_CACHE', '');
define('DIR_DOWNLOAD', '');
define('DIR_CATALOG', '');

// DB
define('DB_DRIVER', 'mysql');
define('DB_HOSTNAME', '');
define('DB_USERNAME', '');
define('DB_PASSWORD', '');
define('DB_DATABASE', '');
define('DB_PREFIX', 'cart_');
?>